using Logica;

namespace Interfaz
{
    public partial class FrmAtencion : Form
    {
        private bool seSeleccionoUnMedico;
        private bool seSeleccionoUnPaciente;


        public FrmAtencion()
        {
            InitializeComponent();
        }

        private void FrmAtencion_Load(object sender, EventArgs e)
        {
            seSeleccionoUnMedico = false;
            seSeleccionoUnPaciente = false;


            lstMedicos.Items.Add(new PersonalMedico("Gustavo", "Rivas", new DateTime(1999, 12, 12), false));
            lstMedicos.Items.Add(new PersonalMedico("Lautaro", "Galarza", new DateTime(1951, 11, 12), true));

            lstPacientes.Items.Add(new Paciente("Mathias", "Bustamante", new DateTime(1998, 6, 16), "Tigre"));
            lstPacientes.Items.Add(new Paciente("Lucas", "Ferrini", new DateTime(1989, 1, 21), "DF"));
            lstPacientes.Items.Add(new Paciente("Lucas", "Rodriguez", new DateTime(1912, 12, 12), "LaBoca"));
            lstPacientes.Items.Add(new Paciente("John Jairo", "Trelles", new DateTime(1978, 8, 30), "Medellin"));
        }


        private void btnAtender_Click(object sender, EventArgs e)
        {
            while (seSeleccionoUnMedico == false || seSeleccionoUnPaciente == false)
            {
                MessageBox.Show("", "Error en los datos", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            //??

            lstMedicos.ClearSelected();
            lstPacientes.ClearSelected();

            MessageBox.Show("", "Atenci�n finalizada", MessageBoxButtons.OK);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lstMedicos_SelectedIndexChanged(object sender, EventArgs e)
        {
            seSeleccionoUnMedico = true;

            //rtbInfoMedico.Text = ??
        }

        private void lstPacientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            seSeleccionoUnPaciente = true;

            //??
        }


        private void FrmAtencion_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("�Seguro que desea salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}
