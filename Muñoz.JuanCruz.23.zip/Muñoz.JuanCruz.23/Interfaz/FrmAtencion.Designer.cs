﻿namespace Interfaz
{
    partial class FrmAtencion
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnAtender = new Button();
            btnSalir = new Button();
            lblMedicos = new Label();
            lblPacientes = new Label();
            lstMedicos = new ListBox();
            lstPacientes = new ListBox();
            rtbInfoMedico = new RichTextBox();
            bindingSource1 = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            SuspendLayout();
            // 
            // btnAtender
            // 
            btnAtender.Location = new Point(905, 53);
            btnAtender.Name = "btnAtender";
            btnAtender.Size = new Size(218, 101);
            btnAtender.TabIndex = 0;
            btnAtender.Text = "Atender";
            btnAtender.UseVisualStyleBackColor = true;
            btnAtender.Click += btnAtender_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(905, 508);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(218, 101);
            btnSalir.TabIndex = 1;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // lblMedicos
            // 
            lblMedicos.AutoSize = true;
            lblMedicos.Location = new Point(112, 20);
            lblMedicos.Name = "lblMedicos";
            lblMedicos.Size = new Size(118, 20);
            lblMedicos.TabIndex = 2;
            lblMedicos.Text = "Personal médico";
            // 
            // lblPacientes
            // 
            lblPacientes.AutoSize = true;
            lblPacientes.Location = new Point(569, 20);
            lblPacientes.Name = "lblPacientes";
            lblPacientes.Size = new Size(70, 20);
            lblPacientes.TabIndex = 3;
            lblPacientes.Text = "Pacientes";
            // 
            // lstMedicos
            // 
            lstMedicos.FormattingEnabled = true;
            lstMedicos.ItemHeight = 20;
            lstMedicos.Location = new Point(12, 53);
            lstMedicos.Name = "lstMedicos";
            lstMedicos.Size = new Size(378, 284);
            lstMedicos.TabIndex = 5;
            lstMedicos.SelectedIndexChanged += lstMedicos_SelectedIndexChanged;
            // 
            // lstPacientes
            // 
            lstPacientes.FormattingEnabled = true;
            lstPacientes.ItemHeight = 20;
            lstPacientes.Location = new Point(432, 53);
            lstPacientes.Name = "lstPacientes";
            lstPacientes.Size = new Size(346, 284);
            lstPacientes.TabIndex = 6;
            lstPacientes.SelectedIndexChanged += lstPacientes_SelectedIndexChanged;
            // 
            // rtbInfoMedico
            // 
            rtbInfoMedico.Location = new Point(12, 343);
            rtbInfoMedico.Name = "rtbInfoMedico";
            rtbInfoMedico.Size = new Size(766, 266);
            rtbInfoMedico.TabIndex = 7;
            rtbInfoMedico.Text = "";
            // 
            // FrmAtencion
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1210, 673);
            Controls.Add(rtbInfoMedico);
            Controls.Add(lstPacientes);
            Controls.Add(lstMedicos);
            Controls.Add(lblPacientes);
            Controls.Add(lblMedicos);
            Controls.Add(btnSalir);
            Controls.Add(btnAtender);
            Name = "FrmAtencion";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Muñoz Juan Cruz";
            FormClosing += FrmAtencion_FormClosing;
            Load += FrmAtencion_Load;
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAtender;
        private Button btnSalir;
        private Label lblMedicos;
        private Label lblPacientes;
        private ListBox lstMedicos;
        private ListBox lstPacientes;
        private RichTextBox rtbInfoMedico;
        private BindingSource bindingSource1;
    }
}
