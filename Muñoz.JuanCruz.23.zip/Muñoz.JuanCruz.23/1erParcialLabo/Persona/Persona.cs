﻿using System.Text;

namespace Logica
{
    public abstract class Persona
    {
        protected string apellido;
        protected string barrioRecidencia;
        protected DateTime nacimiento;
        protected string nombre;


        public int Edad
        {
            get { return DateTime.Today.AddTicks(- this.nacimiento.Ticks).Year - 1; }
        }

        public string NombreCompleto
        {
            get { return apellido + nombre; }
        }


        public Persona(string apellido, DateTime nacimiento, string nombre)
        {
            this.apellido = apellido;
            this.nacimiento = nacimiento;
            this.nombre = nombre;
        }

        public Persona(string apellido, string barrioRecidencia, DateTime nacimiento, string nombre) : this(apellido, nacimiento, nombre)
        {
            this.barrioRecidencia = barrioRecidencia;
        }


        internal abstract string FichaExtra();

        public string FichaPersonal(Persona p)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(apellido + nombre);
            sb.AppendLine("Edad: " + Edad);

            return sb.ToString();
        }

        public override string ToString()
        {
            return apellido + nombre;
        }
    }
}
