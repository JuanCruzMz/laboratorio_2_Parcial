﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class PersonalMedico : Persona
    {
        private List<Consulta> consultas;
        private bool esResidente;


        public PersonalMedico(string apellido, string nombre, DateTime nacimiento, bool esResidente) : base(apellido, nacimiento, nombre)
        {
            this.esResidente = esResidente;
        }


        internal override string FichaExtra()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("¿Finalizó residencia ?" /*{SI / NO}*/);
            sb.AppendLine("ATENCIONES:");
            sb.AppendLine(/*{ Fichas de la lista de CONSULTAS}*/);
            sb.AppendLine("Edad: " + Edad);

            return sb.ToString();
        }
    }
}
