﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class Paciente : Persona
    {
        public string diagnostico;


        public string Diagnostico
        {
            get { return diagnostico; }
        }


        public Paciente(string apellido, string nombre, DateTime nacimiento, string barrioRecidencia) : base(apellido, barrioRecidencia, nacimiento, nombre)
        {

        }


        internal override string FichaExtra()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Recide en: " + barrioRecidencia);
            sb.AppendLine(diagnostico);

            return sb.ToString();
        }
    }
}
